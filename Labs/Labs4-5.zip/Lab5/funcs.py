import numpy as np

def double(a):
    return a**2

def markov(rho, A, nmax):
    
    X = []
    
    N = len(rho) # On suppose alors A de taille NxN
    
    if (A.shape[0] != N or A.shape[1] != N):
        return Exception("Alerte de dimension !")
    
    x = np.random.choice(N, 1, p=rho)[0]
    X.append(x)
    
    for q in range(0, nmax-1):
        
        x = np.random.choice(N, 1, p=A[x].flatten())[0]
        X.append(x)
        
    return X

def run_markov_py(N, nmax=5):
    
    rho = np.random.rand(N)
    rho /= rho.sum()

    A = np.random.rand(N,N)

    for i in range(A.shape[0]):
        A[i] /= np.sum(A[i])

    print(markov(rho, A, nmax))
