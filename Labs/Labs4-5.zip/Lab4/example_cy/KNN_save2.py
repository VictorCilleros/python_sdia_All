from cpython cimport array
import array

import numpy as np

def argsort_k(double[:] liste, Py_ssize_t n, Py_ssize_t k, Py_ssize_t[:] res_view):

    cdef Py_ssize_t i
    cdef Py_ssize_t j

    cdef Py_ssize_t temp1
    cdef Py_ssize_t temp2

    cdef double elt
    
    for i in range(n):

        elt = liste[i]
        
        j = 0
        while(j < k and j < i and liste[res_view[j]] < elt):
            j += 1

        if j < k:
            temp1 = res_view[j]
            res_view[j] = i
        
        j += 1
        while(j < k):
            temp2 = res_view[j]
            res_view[j] = temp1
            temp1 = temp2
            j += 1

def argmax_counts(int[:] lst, Py_ssize_t n, Py_ssize_t[:] counts_view, Py_ssize_t nb_classe_max):
    
    cdef Py_ssize_t res = 0
    cdef int occs = 0

    cdef Py_ssize_t i = 0
    
    for i in range(n):
        counts_view[lst[i]] += 1
        
    for i in range(nb_classe_max):
        if counts_view[i] > occs:
            res = i
            occs = counts_view[res]
        counts_view[i] = 0
            
    return res

def KNN(int K, double[:,:] trainset, int[:] trainclass, double[:,:] testset):

    cdef Py_ssize_t nb_train = trainset.shape[0]
    cdef Py_ssize_t nb_test = testset.shape[0]
    cdef Py_ssize_t nb_classes = max(trainclass)
   
    pred = np.zeros(nb_test, dtype = int)
    cdef int[:] pred_view = pred

    distances = np.zeros(nb_train, dtype = float)
    cdef double[:] distances_view = distances

    votes = np.zeros(K, dtype = int)
    cdef int[:] votes_view = votes

    neighbours = np.zeros(K, dtype = np.intp) 
    cdef Py_ssize_t[:] neighbours_view = neighbours

    counts = np.zeros(nb_classes+1, dtype = np.intp)
    cdef Py_ssize_t[:] counts_view = counts

    cdef Py_ssize_t i
    cdef Py_ssize_t j
    cdef Py_ssize_t k

    cdef double train_point_x
    cdef double train_point_y
    cdef double test_point_x
    cdef double test_point_y
    
    for i in range(nb_test):

        test_point_x = testset[i,0]
        test_point_y = testset[i,1]

        for j in range(nb_train):
            train_point_x = trainset[j,0]
            train_point_y = trainset[j,1]
            distances_view[j] = (train_point_x - test_point_x)*(train_point_x - test_point_x) + (train_point_y - test_point_y)*(train_point_y - test_point_y)

        argsort_k(distances_view, nb_train, K, neighbours_view) # InPlace Op

        for k in range(K):
            votes_view[k] = trainclass[neighbours_view[k]]

        pred_view[i] = argmax_counts(votes_view, K, counts_view, nb_classes+1)

    return pred
