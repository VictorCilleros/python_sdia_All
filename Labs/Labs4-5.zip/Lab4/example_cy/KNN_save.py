from cpython cimport array
import array

import numpy as np

def argsort_k(double[:] liste, Py_ssize_t k, Py_ssize_t[:] res_view):
    
    cdef int n = len(liste)

    cdef Py_ssize_t i
    cdef Py_ssize_t j

    cdef Py_ssize_t temp1
    cdef Py_ssize_t temp2
    
    for i in range(n):
        
        j = 0
        while(j < k and j < i and liste[res_view[j]] < liste[i]):
            j += 1

        if j < k:
            temp1 = res_view[j]
            res_view[j] = i
        
        j += 1
        while(j < k):
            temp2 = res_view[j]
            res_view[j] = temp1
            temp1 = temp2
            j += 1

def argmax_counts(int[:] lst, Py_ssize_t n, Py_ssize_t nb_classe_max):
    
    counts = np.zeros(nb_classe_max, dtype = np.intp)
    cdef Py_ssize_t[:] counts_view = counts
    
    cdef Py_ssize_t res = 0
    cdef int occs = 0

    cdef Py_ssize_t i = 0
    
    for i in range(n):
        counts_view[lst[i]] += 1
        
    for i in range(nb_classe_max):
        if counts_view[i] > occs:
            res = i
            occs = counts_view[res]
            
    return res

def KNN(int K, double[:,:] trainset, int[:] trainclass, double[:,:] testset, int debug):

    cdef Py_ssize_t nb_train = trainset.shape[0]
    cdef Py_ssize_t nb_test = testset.shape[0]
    cdef Py_ssize_t nb_classes = max(trainclass)
   
    pred = np.zeros(nb_test, dtype = int)
    cdef int[:] pred_view = pred

    if debug:
        print("A", end = '', flush=True)

    distances = np.zeros(nb_train, dtype = float)
    cdef double[:] distances_view = distances

    votes = np.zeros(K, dtype = int)
    cdef int[:] votes_view = votes

    neighbours = np.zeros(K, dtype = np.intp) 
    cdef Py_ssize_t[:] neighbours_view = neighbours

    cdef Py_ssize_t i
    cdef Py_ssize_t j
    cdef Py_ssize_t k
    
    for i in range(nb_test):

        if debug:
            print("B", end = '', flush=True)

        for j in range(nb_train):
            distances_view[j] = (trainset[j,0] - testset[i,0])*(trainset[j,0] - testset[i,0]) + (trainset[j,1] - testset[i,1])*(trainset[j,1] - testset[i,1])

        if debug:
            print("C", end = '', flush=True)

        argsort_k(distances_view, K, neighbours_view) # InPlace Op

        if debug:
            print("D", end = '', flush=True)

        for k in range(K):
            votes_view[k] = trainclass[neighbours_view[k]]
        
        #counts = np.bincount(votes)

        if debug:
            print("E", end = '', flush=True)

        #pred[i] = np.argmax(counts)
        pred[i] = argmax_counts(votes_view, K, nb_classes+1)

        if debug:
            print("F", end = '', flush=True)

    if debug:
        print("G", end = '', flush=True)

    return pred

def test(liste):
    
    cdef array.array a = array.array('i', liste)
    cdef int[:] ca = a

    print(ca[0])
