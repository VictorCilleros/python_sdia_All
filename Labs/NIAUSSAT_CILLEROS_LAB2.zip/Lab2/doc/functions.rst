Discrete isotropic total variation
=======================================

.. autofunction:: functions.gradient2D

.. autofunction:: functions.gradient2D_adjoint

.. autofunction:: functions.tv